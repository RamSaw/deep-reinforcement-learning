import os
import pickle
import random

import numpy as np
import sklearn
import torch
from sklearn.kernel_approximation import RBFSampler
from sklearn.pipeline import FeatureUnion
from sklearn.linear_model import SGDRegressor
from torch import optim, nn
import pickle
import random
from collections import deque

import numpy as np
import torch
from gym import make
from sklearn.linear_model import SGDRegressor
from torch import optim, nn

SEED = 41


def make_reproducible(seed, make_cuda_reproducible):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if make_cuda_reproducible:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


make_reproducible(SEED, False)


class Transformer:
    def __init__(self, env) -> None:
        observation_examples = np.array([env.observation_space.sample() for x in range(10000)])
        scaler = sklearn.preprocessing.StandardScaler()
        scaler.fit(observation_examples)

        state_transformer = FeatureUnion([
            ("rbf1", RBFSampler(gamma=5.0, n_components=5)),
            ("rbf2", RBFSampler(gamma=2.0, n_components=5)),
            ("rbf3", RBFSampler(gamma=1.0, n_components=5)),
            ("rbf4", RBFSampler(gamma=0.5, n_components=5))
        ])
        state_transformer.fit(scaler.transform(observation_examples))
        self.state_transformer = state_transformer
        self.scaler = scaler

    def transform_state(self, state):
        return self.state_transformer.transform(self.scaler.transform([state]))


class Agent:
    def __init__(self):
        self.agent_filepath = "new_agent.pt"
        with open(self.agent_filepath, 'rb') as f:
            self.models, self.transformer = pickle.load(f)

    def act(self, state):
        return np.argmax(self.forward(state))

    def forward(self, state):
        transformed_state = self.transformer.transform_state(state)
        return [self.models[i].predict(transformed_state) for i in range(3)]

    def reset(self):
        pass

    def save(self):
        with open(self.agent_filepath, 'wb') as f:
            pickle.dump((self.models, self.transformer), f)
